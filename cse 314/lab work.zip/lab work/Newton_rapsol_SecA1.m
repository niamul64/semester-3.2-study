﻿%   Use Newton-Raphson method to estimate the root of x^4−4x^(3/2)+5x+2= 0. Conduct 3 iterations assuming that the root exists in the interval of [4, 6]. Find the absolute relative approximate error and the number of significant digits at least correct at the end of each iteration. Use four decimal digit arithmetic to find a solution.
x1=5;
f = @(x) ((x^4)-(4*x^(3/2))+(5*x)+2);

fprime = @(x) ((4*x^3)-(6*x^(1/2))+5);

iter=0;
agerX=0;
sigDigit=0;
while iter<3
    agerX=x1;
    iter=iter+1;
    x2=x1-f(x1)/fprime(x1);
    x1=x2;
    rele=abs(((x2-agerX)/x2)*100);
    
    if rele<0.5
        sigDigit=2;
    
    elseif rele<5
        sigDigit=1;

    else
        sigDigit=0;
    endif
    
    disp (['After iteration ', num2str(iter), ' the root is: ', num2str(x2),' significat digit:',num2str(sigDigit),' error:', num2str(rele)]);
end