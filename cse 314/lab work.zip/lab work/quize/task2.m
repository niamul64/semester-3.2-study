allMarks=[24,44,36,36;52,57,68,76;
66,53,69,73;
85,40,86,72;
15,47,25,28;
79 ,72,82, 91]

scale_down_marks=allMarks*.25

marks_out_of_60=allMarks*.60;
Chetans_mark= marks_out_of_60(3,:)
Chetans_mark_total=sum(Chetans_mark)

mean(marks_out_of_60(:,3:4))