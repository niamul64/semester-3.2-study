z = [3.5, 5, -6.2, -11, 0, -8.1, 9, 0, 3, 1, -3, 2.5]

numberOfElementsIn_vector=size(z,2);
t=[];
add=0;

w=1;

while w<=numberOfElementsIn_vector
  
  add=add+z(w);
  w++;
endwhile

add

for i=1:numberOfElementsIn_vector
  
  if (z(i)>=0)
    t=[t,z(i)];
  
  endif
  
endfor
 

t